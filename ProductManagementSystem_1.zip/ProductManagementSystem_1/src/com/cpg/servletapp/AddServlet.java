package com.cpg.servletapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cpg.dao.DaoClass;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		DaoClass dao = new DaoClass();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String productName = request.getParameter("pname");
		String productModel = request.getParameter("pmodel");
		String productId = request.getParameter("pid");
		String price = request.getParameter("pprice");

		if (dao.addProduct(productId, productName, productModel, price)) {
			out.println("Successfully added product with id:" + productId);
			RequestDispatcher rd = request.getRequestDispatcher("addview.jsp");
			rd.include(request, response);

		} else {
			out.println("Not added ..try after some time");
		}
	}

}
