package com.cpg.servletapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cpg.dao.DaoClass;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoClass dao=new DaoClass();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		String contact =request.getParameter("phno");
		String emailid= request.getParameter("mail");
		if(dao.addUser(username, password, contact, emailid))
		{
			out.println("Successfully added user");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request,response);
			
		}
		else
		{
			out.println("Not inserted ..try after some time");
		}
	}

}
