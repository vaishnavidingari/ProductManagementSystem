package com.cpg.servletapp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cpg.dao.DaoClass;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		DaoClass dao = new DaoClass();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String productId = request.getParameter("pid");
		String price = request.getParameter("price");
		int n = dao.editProduct(productId, price);
		if (n > 0) {
			out.println("Successfully updated price fro product with id:"+ productId);
			RequestDispatcher rd = request.getRequestDispatcher("addview.jsp");
			rd.include(request, response);

		} else {
			out.println("Not updated ..try after some time");
		}
	}

}
