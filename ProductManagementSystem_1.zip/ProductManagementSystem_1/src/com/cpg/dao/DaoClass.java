package com.cpg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DaoClass {
	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
			con = DriverManager.getConnection(url, user, pass);
			return con;

		} catch (Exception e) {

			//e.printStackTrace();

		}

		return con;

	}

	public boolean checkUser(String username, String password) {
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "select * from user_details where username=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs = null;
			try {
				rs = ps.executeQuery();
				rs.next();
				if (rs.getString(2).equals(password)) {
					return true;
				} else {
					return false;
				}
			}

			catch (Exception e) {
				// TODO: handle exception
			//	e.printStackTrace();
				return false;
			}
		}

		catch (Exception e) {

			//e.printStackTrace();
			return false;
		}

	}

	public boolean addUser(String username, String password, String contact,
			String email) {
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "insert into user_details values(?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, email);
			ps.setString(4, contact);
			int rs = 0;
			try {
				rs = ps.executeUpdate();

				if (rs == 1) {
					return true;
				} else {
					return false;
				}
			}

			catch (Exception e) {
				// TODO: handle exception
				//e.printStackTrace();
				return false;
			}
		}

		catch (Exception e) {

			//e.printStackTrace();
			return false;
		}

	}

	public int editProduct(String pid, String price) {

		Connection con = getConnection();
		PreparedStatement ps = null;
		String sql = "update products set price=? where pid=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, price);
			ps.setString(2, pid);
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			//e.printStackTrace();
			return 0;
		}

	}

	public int deleteProduct(String productId) {
		Connection con = getConnection();
		PreparedStatement ps = null;
		String sql = "delete from products where pid=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, productId);
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			//e.printStackTrace();
			return 0;
		}
	}

	public boolean addProduct(String productId, String productName,
			String productModel, String price) {
		PreparedStatement ps = null;
		Connection con = getConnection();
		String sql = "insert into products values(?,?,?,?)";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, productId);
			ps.setString(2, productName);
			ps.setString(3, productModel);
			ps.setString(4, price);
			int rs = 0;
			try {
				rs = ps.executeUpdate();

				if (rs == 1) {
					return true;
				} else {
					return false;
				}
			}

			catch (Exception e) {
				// TODO: handle exception
				//e.printStackTrace();
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			//e.printStackTrace();
			return false;

		}
	}

	public int changeUserPassword(String username, String newPassword) {
		Connection con = getConnection();
		PreparedStatement ps = null;
		String sql = "update user_details set password=? where username=?";

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, newPassword);
			ps.setString(2, username);
			int n = ps.executeUpdate();
			return n;
		}

		catch (Exception e) {

			
			return 0;
		}
	}

	
}
